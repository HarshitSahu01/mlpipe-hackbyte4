import os
import json
import pickle
import pandas as pd
import numpy as np

# Pipeline paths (mapped in Docker)
INPUT_DIR = "/tmp/input"
OUTPUT_DIR = "/tmp/output"
INPUT_FILE = os.path.join(INPUT_DIR, "input.json")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "output.json")

def load_model():
    model_path = "regressor.pkl"
    with open(model_path, "rb") as f:
        return pickle.load(f)

def run_inference():
    print("🚀 House Regressor: Starting Inference...")
    
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Error: Input file not found at {INPUT_FILE}")
        return

    with open(INPUT_FILE, "r") as f:
        input_data = json.load(f)

    # Assuming input data has a 'data' key with a list of feature dictionaries
    # or a 2D array of features.
    # The training features were: ['Lot Area', 'Overall Qual', 'Year Built', 'Full Bath', 'Gr Liv Area']
    df_input = pd.DataFrame(input_data.get("data", []))
    
    # Ensure all required features are present
    required_features = ['Lot Area', 'Overall Qual', 'Year Built', 'Full Bath', 'Gr Liv Area']
    for feat in required_features:
        if feat not in df_input.columns:
            df_input[feat] = 0 # Default if missing
    
    X = df_input[required_features].fillna(0)
    
    model = load_model()
    predictions = model.predict(X).tolist()

    # Specific format requested:
    # { "status": "success", "step": "inference", "predictions": predictions }
    output = {
        "status": "success",
        "step": "inference",
        "predictions": predictions,
        # We pass through listing price if it exists in the original input to help the next model
        "listing_prices": input_data.get("listing_prices", [])
    }

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump(output, f)

    print(f"✅ House Regressor: Results saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    run_inference()
